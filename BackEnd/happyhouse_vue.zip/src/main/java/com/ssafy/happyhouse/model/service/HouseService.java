package com.ssafy.happyhouse.model.service;

import java.util.List;
import java.util.Map;

import org.json.JSONArray;

import com.ssafy.happyhouse.model.JjimDto;
import com.ssafy.happyhouse.model.*;

public interface HouseService {
	 
	List<SidoGugunCodeDto> getSido() throws Exception;
	List<SidoGugunCodeDto> getGugunInSido(String sido) throws Exception;
	List<HouseInfoDto> getDongInGugun(String gugun) throws Exception;
	List<HouseInfoDto> getAptInDong(String dong) throws Exception;
	List<HouseDealDto> getHouseDealInApt(int aptCode) throws Exception;
	List<JjimDto> listJjim(String userId);
	List<AptInfoDto> getHouseList(Map<String, String> map) throws Exception;
    JSONArray getHouseDeal(Map<String, String> map) throws Exception;
	
}

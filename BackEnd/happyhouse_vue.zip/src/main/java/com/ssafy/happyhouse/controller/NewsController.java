package com.ssafy.happyhouse.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.NewsDto;

@RestController
@RequestMapping("/news")
public class NewsController {
   
   @GetMapping("/list")
   private ResponseEntity<List<NewsDto>> list(@RequestParam Map<String, String> map) throws Exception{
      String cityNo = map.get("cityNo");
      String dvsnNo = map.get("dvsnNo");
      
      String url= "https://land.naver.com/news/region.naver?city_no=" + cityNo + "&dvsn_no=" + dvsnNo;
      
      Document doc = Jsoup.connect(url).get();
      
      Elements element = doc.select("ul.headline_list");
      
      List<NewsDto> newsList = new ArrayList<NewsDto>();
      
      for(Element el : element.select("li")) {
         System.out.println(el.select("a").select("img").attr("abs:src")); // 이미지 url
         System.out.println(el.select("a").attr("abs:href")); //news url
         System.out.println(el.select("dt").select("a").text()); // 뉴스 제목
         System.out.println(el.select("dd").text()); // 내용
         System.out.println(el.select("span.writing").text()); // 작성언론
         System.out.println(el.select("span.date").text()); // 작성일자
         
         NewsDto newsDto = new NewsDto();
         if(el.select("a").select("img") != null) {
            newsDto.setImgUrl(el.select("a").select("img").attr("abs:src")); // 이미지 url
         }
         newsDto.setUrl(el.select("a").attr("abs:href")); //  (뉴스 url)
         newsDto.setTitle(el.select("dt").select("a").text()); // 뉴스 제목
         newsDto.setContent(el.select("dd").text()); // 내용
         newsDto.setWriting(el.select("span.writing").text()); // 작성언론
         newsDto.setDate(el.select("span.date").text()); // 작성일자
         
         newsList.add(newsDto);
      }
      
      return new ResponseEntity<List<NewsDto>>(newsList , HttpStatus.OK);
   }
}
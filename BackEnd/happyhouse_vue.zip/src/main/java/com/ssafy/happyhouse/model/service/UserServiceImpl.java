package com.ssafy.happyhouse.model.service;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.mapper.UserMapper;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public UserDto login(UserDto userDto) throws Exception {
		if(userDto.getUserId() == null || userDto.getPassword() == null)
			return null;
		return sqlSession.getMapper(UserMapper.class).login(userDto);
	}

	@Override
	public UserDto userInfo(String id) throws Exception {
		return sqlSession.getMapper(UserMapper.class).userInfo(id);
	}
	
	@Override
	public int idCheck(String id) throws Exception {
		return sqlSession.getMapper(UserMapper.class).idCheck(id);
	}

	@Override
	public void registerUser(UserDto userDto) throws Exception {
		sqlSession.getMapper(UserMapper.class).registerUser(userDto);
	}

//	@Override
//	public UserDto login(UserDto userDto) throws Exception {
//		return sqlSession.getMapper(UserMapper.class).login(userDto);
//	}

	@Override
	public UserDto getUser(String id) throws Exception {
		return sqlSession.getMapper(UserMapper.class).getUser(id);
	}

	@Override
	public void updateUser(UserDto userDto) throws Exception {
		sqlSession.getMapper(UserMapper.class).updateUser(userDto);
	}

	@Override
	public void deleteUser(String id) throws Exception {
		sqlSession.getMapper(UserMapper.class).deleteUser(id);
	}

}
